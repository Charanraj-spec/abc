const sqlite3 = require('sqlite3').verbose();
// Path to the database file
const DB_PATH = './bloodbank.db'; 

const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error("Error opening database " + err.message);
    } else {
        console.log('✅ Connected to the SQLite database: bloodbank.db');
        db.serialize(() => {
            db.run("PRAGMA foreign_keys = ON;"); 
            createTables(db);
        });
    }
});

function createTables(db) {
    console.log("Creating database tables...");

    const createTableQueries = [
        // 1. LOGIN (Table 10 from ER mapping)
        `CREATE TABLE IF NOT EXISTS LOGIN (
            User_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            Username TEXT NOT NULL UNIQUE,
            Password TEXT NOT NULL,
            Role TEXT NOT NULL, -- (donar/bloodbank/hospital/admin)
            Status TEXT DEFAULT 'active',
            Email TEXT UNIQUE,
            Phone TEXT
        )`,

        // 2. DONAR (Table 1 from ER mapping)
        `CREATE TABLE IF NOT EXISTS DONAR (
            D_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            D_name TEXT NOT NULL,
            Phone TEXT,
            Age INTEGER,
            Address TEXT,
            Weight REAL,
            Gender TEXT,
            Blood_Group TEXT, -- Added for easier search/donation tracking
            disease_status TEXT -- (e.g., None, HIV, etc.)
        )`,
        
        // 3. HOSPITAL (Table 2 from ER mapping)
        `CREATE TABLE IF NOT EXISTS HOSPITAL (
            E_ID INTEGER PRIMARY KEY AUTOINCREMENT, 
            E_name TEXT NOT NULL,
            Phone TEXT
        )`,
        
        // 4. BLOOD (Table 5 from ER mapping)
        `CREATE TABLE IF NOT EXISTS BLOOD (
            B_code TEXT PRIMARY KEY, -- Using Blood Group (e.g., 'A+') as B_code
            B_type TEXT NOT NULL UNIQUE,
            Availabilty_quantity INTEGER NOT NULL
        )`,
        
        // 5. BLOOD_BANK (Table 6 from ER mapping)
        `CREATE TABLE IF NOT EXISTS BLOOD_BANK (
            BB_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            BB_name TEXT NOT NULL,
            Address TEXT
        )`,

        // 6. REGISTER (Donor-Hospital M:N, Table 3 from ER mapping)
        `CREATE TABLE IF NOT EXISTS REGISTER (
            D_ID INTEGER NOT NULL,
            E_ID INTEGER NOT NULL,
            PRIMARY KEY (D_ID, E_ID),
            FOREIGN KEY (D_ID) REFERENCES DONAR(D_ID) ON DELETE CASCADE,
            FOREIGN KEY (E_ID) REFERENCES HOSPITAL(E_ID) ON DELETE CASCADE
        )`,
        
        // 7. DONATE (Donation Record, Table 4 from ER mapping)
        `CREATE TABLE IF NOT EXISTS DONATE (
            Donation_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            D_ID INTEGER NOT NULL,
            B_code TEXT NOT NULL,
            date TEXT NOT NULL,
            FOREIGN KEY (D_ID) REFERENCES DONAR(D_ID) ON DELETE CASCADE,
            FOREIGN KEY (B_code) REFERENCES BLOOD(B_code) ON DELETE CASCADE
        )`,

        // 8. STORED (Blood-Blood Bank M:N, Table 7 from ER mapping)
        `CREATE TABLE IF NOT EXISTS STORED (
            B_code TEXT NOT NULL,
            BB_ID INTEGER NOT NULL,
            PRIMARY KEY (B_code, BB_ID),
            FOREIGN KEY (B_code) REFERENCES BLOOD(B_code) ON DELETE CASCADE,
            FOREIGN KEY (BB_ID) REFERENCES BLOOD_BANK(BB_ID) ON DELETE CASCADE
        )`,
        
        // 9. ORDERS (Table 8 from ER mapping)
        `CREATE TABLE IF NOT EXISTS ORDERS (
            Order_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            E_ID INTEGER NOT NULL,
            Date TEXT NOT NULL,
            FOREIGN KEY (E_ID) REFERENCES HOSPITAL(E_ID) ON DELETE CASCADE
        )`,
        
        // 10. ORDER_DETAILS (Table 9 from ER mapping)
        `CREATE TABLE IF NOT EXISTS ORDER_DETAILS (
            Order_ID INTEGER NOT NULL,
            B_code TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            PRIMARY KEY (Order_ID, B_code),
            FOREIGN KEY (Order_ID) REFERENCES ORDERS(Order_ID) ON DELETE CASCADE,
            FOREIGN KEY (B_code) REFERENCES BLOOD(B_code) ON DELETE CASCADE
        )`,
        
        // 11. DONOR_LOGIN (Linking Table 11 from ER mapping)
        `CREATE TABLE IF NOT EXISTS DONOR_LOGIN (
            D_ID INTEGER NOT NULL,
            User_ID INTEGER NOT NULL,
            PRIMARY KEY (D_ID, User_ID),
            FOREIGN KEY (D_ID) REFERENCES DONAR(D_ID) ON DELETE CASCADE,
            FOREIGN KEY (User_ID) REFERENCES LOGIN(User_ID) ON DELETE CASCADE
        )`,
        
        // 12. BLOODBANK_LOGIN (Linking Table 12 from ER mapping)
        `CREATE TABLE IF NOT EXISTS BLOODBANK_LOGIN (
            BB_ID INTEGER NOT NULL,
            User_ID INTEGER NOT NULL,
            PRIMARY KEY (BB_ID, User_ID),
            FOREIGN KEY (BB_ID) REFERENCES BLOOD_BANK(BB_ID) ON DELETE CASCADE,
            FOREIGN KEY (User_ID) REFERENCES LOGIN(User_ID) ON DELETE CASCADE
        )`
    ];

    createTableQueries.forEach(query => {
        db.run(query, (err) => {
            if (err) console.error("Error creating table: " + err.message);
        });
    });
    
    // Initialize standard blood types with 0 stock
    const bloodTypes = ['A+', 'O+', 'B+', 'AB+', 'A-', 'O-', 'B-', 'AB-'];
    bloodTypes.forEach(type => {
        // B_code is the same as B_type for simplicity
        db.run(`INSERT OR IGNORE INTO BLOOD (B_code, B_type, Availabilty_quantity) VALUES (?, ?, 0)`, 
               [type, type], 
               (err) => {
                    if (err) console.error("Error inserting initial blood type:", err.message);
        });
    });

    console.log("✅ Database schema setup complete.");
    db.close((err) => {
        if (err) console.error(err.message);
        console.log('🔌 Database connection closed.');
    });
}