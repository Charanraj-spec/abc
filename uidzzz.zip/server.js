const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors'); 
const app = express();
const port = 3000;

// --- Middleware ---
app.use(express.json());
// CORS: Allows your frontend HTML files to fetch data from this server
app.use(cors()); 

// Function to get a fresh database connection
function getDbConnection() {
    return new sqlite3.Database('./bloodbank.db', sqlite3.OPEN_READWRITE);
}

// Global Welcome Endpoint
app.get('/', (req, res) => {
    res.send('Blood Donation Management System Backend Running!');
});

// =========================================================
// 1. ENDPOINT: DONOR REGISTRATION (Used by donor sign-up forms)
// =========================================================
app.post('/api/register-donor', async (req, res) => {
    const { 
        D_name, phone, age, address, weight, gender, blood_group, 
        username, password, email 
    } = req.body;

    if (!D_name || !username || !password || !blood_group) {
        return res.status(400).json({ message: "Missing required fields for registration." });
    }

    const db = getDbConnection();
    db.serialize(() => {
        db.run("BEGIN TRANSACTION;");

        // Step 1: Insert into LOGIN table
        db.run(`INSERT INTO LOGIN (Username, Password, Role, Email, Phone) 
                VALUES (?, ?, 'donar', ?, ?)`, 
                [username, password, email, phone], function(err) {
            
            if (err) {
                db.run("ROLLBACK;");
                db.close();
                if (err.message.includes('UNIQUE constraint failed')) {
                    return res.status(409).json({ message: "Username or Email already exists." });
                }
                console.error(err.message);
                return res.status(500).json({ message: "Failed to create login account." });
            }
            const user_id = this.lastID;

            // Step 2: Insert into DONAR table
            db.run(`INSERT INTO DONAR (D_name, Phone, Age, Address, Weight, Gender, Blood_Group, disease_status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'None')`,
                    [D_name, phone, age, address, weight, gender, blood_group], function(err) {

                if (err) {
                    db.run("ROLLBACK;");
                    db.close();
                    console.error(err.message);
                    return res.status(500).json({ message: "Failed to create donor profile." });
                }
                const donor_id = this.lastID;

                // Step 3: Insert into DONOR_LOGIN linking table
                db.run(`INSERT INTO DONOR_LOGIN (D_ID, User_ID) VALUES (?, ?)`, 
                        [donor_id, user_id], function(err) {
                    
                    if (err) {
                        db.run("ROLLBACK;");
                        db.close();
                        console.error(err.message);
                        return res.status(500).json({ message: "Failed to link donor to login." });
                    }

                    db.run("COMMIT;", (commitErr) => {
                        db.close();
                        if (commitErr) {
                            console.error(commitErr.message);
                            return res.status(500).json({ message: "Transaction commit failed." });
                        }
                        res.status(201).json({ 
                            message: "Donor registered successfully!", 
                            D_ID: donor_id
                        });
                    });
                });
            });
        });
    });
});

// =========================================================
// 2. ENDPOINT: BLOOD BANK REGISTRATION (Used by bloodbank.html)
// =========================================================
app.post('/api/register-bloodbank', async (req, res) => {
    const { 
        BB_name, address, username, password, email, phone 
    } = req.body;

    if (!BB_name || !username || !password) {
        return res.status(400).json({ message: "Missing required fields for blood bank registration." });
    }

    const db = getDbConnection();
    db.serialize(() => {
        db.run("BEGIN TRANSACTION;");

        // Step 1: Insert into LOGIN table (Role: bloodbank)
        db.run(`INSERT INTO LOGIN (Username, Password, Role, Email, Phone) 
                VALUES (?, ?, 'bloodbank', ?, ?)`, 
                [username, password, email, phone], function(err) {
            
            if (err) {
                db.run("ROLLBACK;");
                db.close();
                if (err.message.includes('UNIQUE constraint failed')) {
                    return res.status(409).json({ message: "Username or Email already exists." });
                }
                console.error(err.message);
                return res.status(500).json({ message: "Failed to create login account." });
            }
            const user_id = this.lastID;

            // Step 2: Insert into BLOOD_BANK table
            db.run(`INSERT INTO BLOOD_BANK (BB_name, Address) 
                    VALUES (?, ?)`,
                    [BB_name, address], function(err) {

                if (err) {
                    db.run("ROLLBACK;");
                    db.close();
                    console.error(err.message);
                    return res.status(500).json({ message: "Failed to create blood bank profile." });
                }
                const bb_id = this.lastID;

                // Step 3: Insert into BLOODBANK_LOGIN linking table
                db.run(`INSERT INTO BLOODBANK_LOGIN (BB_ID, User_ID) VALUES (?, ?)`, 
                        [bb_id, user_id], function(err) {
                    
                    if (err) {
                        db.run("ROLLBACK;");
                        db.close();
                        console.error(err.message);
                        return res.status(500).json({ message: "Failed to link blood bank to login." });
                    }

                    db.run("COMMIT;", (commitErr) => {
                        db.close();
                        if (commitErr) {
                            console.error(commitErr.message);
                            return res.status(500).json({ message: "Transaction commit failed." });
                        }
                        res.status(201).json({ 
                            message: "Blood Bank registered successfully!", 
                            BB_ID: bb_id
                        });
                    });
                });
            });
        });
    });
});


// =========================================================
// 3. ENDPOINT: SEARCH DONORS (Used by search.html or jj.html)
// =========================================================
app.post('/api/search-donors', (req, res) => {
    const { bloodGroup, location } = req.body;
    
    if (!bloodGroup) {
        return res.status(400).json({ message: "Blood group is required for search." });
    }

    let sql = `
        SELECT D_ID, D_name, Phone, Address, Blood_Group 
        FROM DONAR 
        WHERE Blood_Group = ?
    `;
    let params = [bloodGroup];

    if (location) {
        sql += ` AND Address LIKE ?`;
        params.push(`%${location}%`);
    }

    const db = getDbConnection();
    db.all(sql, params, (err, rows) => {
        db.close();
        if (err) {
            console.error("Database error:", err.message);
            return res.status(500).json({ "error": "Internal server error during search." });
        }
        
        res.json({
            "message": rows.length > 0 ? "success" : "No donors found matching the criteria.",
            "data": rows
        });
    });
});


// =========================================================
// 4. ENDPOINT: GET BLOOD STOCK (Used by jj.html for availability)
// =========================================================
app.get('/api/blood-stock', (req, res) => {
    // Get total stock available for all blood types
    const sql = `SELECT B_type, Availabilty_quantity FROM BLOOD`;
    
    const db = getDbConnection();
    db.all(sql, [], (err, rows) => {
        db.close();
        if (err) {
            console.error("Database error:", err.message);
            return res.status(500).json({ "error": "Internal server error." });
        }
        
        res.json({
            "message": "success",
            "data": rows
        });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`\n🎉 Local backend server listening at http://localhost:${port}`);
    console.log(`\n--- EXECUTION STEPS ---`);
    console.log(`1. Ensure you ran 'npm install' first.`);
    console.log(`2. Run 'node database.js' once to create the DB.`);
    console.log(`3. Keep this server running by running 'node server.js'.`);
    console.log(`4. Open your HTML files to connect to the server.\n`);
});