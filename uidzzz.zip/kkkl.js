  document.addEventListener('DOMContentLoaded', function() {
            // Show loading screen for 1.5 seconds
            setTimeout(function() {
                document.getElementById('loading-screen').style.display = 'none';
            }, 1500);
            
            // Animate stats counter
            const statNumbers = document.querySelectorAll('.stat-number');
            
            function animateStats() {
                statNumbers.forEach(stat => {
                    const target = parseInt(stat.getAttribute('data-target'));
                    const current = parseInt(stat.textContent);
                    
                    if (current < target) {
                        const increment = Math.ceil(target / 20);
                        stat.textContent = Math.min(current + increment, target);
                        setTimeout(animateStats, 80);
                    }
                });
            }
            
            // Start animation when page loads
            setTimeout(animateStats, 500);
            
            // Accordion functionality
            const accordionHeaders = document.querySelectorAll('.accordion-header');
            
            accordionHeaders.forEach(header => {
                header.addEventListener('click', function() {
                    // Close all other accordion items
                    accordionHeaders.forEach(h => {
                        if (h !== this) {
                            h.classList.remove('active');
                            h.nextElementSibling.style.maxHeight = '0';
                        }
                    });
                    
                    // Toggle current item
                    this.classList.toggle('active');
                    const content = this.nextElementSibling;
                    
                    if (this.classList.contains('active')) {
                        content.style.maxHeight = content.scrollHeight + 'px';
                    } else {
                        content.style.maxHeight = '0';
                    }
                });
            });
            
            // Open first accordion by default
            accordionHeaders[0].click();
            
            // Modal functionality
            const modal = document.getElementById('donation-modal');
            const findCenterBtn = document.getElementById('find-center');
            const closeModal = document.getElementById('close-modal');
            const locationForm = document.getElementById('location-form');
            const centersList = document.getElementById('centers-list');
            
            findCenterBtn.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'flex';
            });
            
            closeModal.addEventListener('click', function() {
                modal.style.display = 'none';
            });
            
            window.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
            
            locationForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const location = document.getElementById('location').value;
                
                // Simulate searching for donation centers
                centersList.innerHTML = '<p>Searching for donation centers near ' + location + '...</p>';
                
                setTimeout(function() {
                    // Mock data for demonstration
                    const centers = [
                        {
                            name: 'Community Blood Center',
                            address: '123 Main St, ' + location,
                            phone: '(555) 123-4567'
                        },
                        {
                            name: 'Red Cross Donation Center',
                            address: '456 Oak Ave, ' + location,
                            phone: '(555) 987-6543'
                        },
                        {
                            name: 'Hospital Blood Bank',
                            address: '789 Medical Blvd, ' + location,
                            phone: '(555) 555-5555'
                        }
                    ];
                    
                    let html = '<h3>Blood Donation Centers Near ' + location + '</h3>';
                    html += '<div style="display: flex; flex-direction: column; gap: 15px; margin-top: 15px;">';
                    
                    centers.forEach(center => {
                        html += `
                            <div style="background-color: #f9f9f9; padding: 15px; border-radius: 8px; border-left: 4px solid var(--primary);">
                                <h4 style="margin: 0 0 5px 0;">${center.name}</h4>
                                <p style="margin: 0 0 5px 0;">${center.address}</p>
                                <p style="margin: 0;">${center.phone}</p>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    html += '<p style="margin-top: 15px; font-style: italic;">Note: This is simulated data for demonstration purposes.</p>';
                    
                    centersList.innerHTML = html;
                }, 1000);
            });
        });
